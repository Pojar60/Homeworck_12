public class Visitor {
 int placeVisitor;
}
